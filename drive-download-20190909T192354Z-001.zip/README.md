De-Mining with UAVs MQP
===
*Arthur Lockman, Tucker Haydon, and Greg Tighe*
